class Player{
  constructor(x, y){
    this.x = x; this.y = y;
    this.size = 12;          // player sprite size in pixels (drawn centered)
    this.color = '#e0dccf';
    this.speed = 3.0;        // tiles per second
  }
  tryMove(nx, ny, dungeon){
    // Collide with walls (1 = wall)
    if (isWalkable(nx, this.y, dungeon)) this.x = nx;
    if (isWalkable(this.x, ny, dungeon)) this.y = ny;
  }
  update(keys, dungeon){
    const dt = 1/60; // fixed step feel
    let dx=0, dy=0;
    if(keys['ArrowUp'])    dy -= 1;
    if(keys['ArrowDown'])  dy += 1;
    if(keys['ArrowLeft'])  dx -= 1;
    if(keys['ArrowRight']) dx += 1;
    if(dx||dy){
      const len = Math.hypot(dx,dy); dx/=len; dy/=len;
      const nx = this.x + dx * this.speed * dt;
      const ny = this.y + dy * this.speed * dt;
      this.tryMove(nx, ny, dungeon);
    }
  }
  draw(ctx, px, py){
    // body
    ctx.fillStyle = this.color;
    ctx.fillRect(px, py, this.size, this.size);
    // hood
    ctx.fillStyle = '#9d9b90';
    ctx.fillRect(px, py-3, this.size, 3);
    // shadow
    ctx.globalAlpha = 0.25; ctx.fillStyle='#000';
    ctx.fillRect(px-2, py+this.size-2, this.size+4, 2);
    ctx.globalAlpha = 1;
  }
}
