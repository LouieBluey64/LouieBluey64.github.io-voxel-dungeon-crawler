function drawUI(ctx, player){
  // hearts/hunger/energy placeholders (Phase 1 UI only)
  ctx.fillStyle = '#e8e8ee';
  ctx.font = '8px monospace';
  ctx.fillText('♥ Hearts: 10', 6, 10);
  ctx.fillText('🍗 Hunger: 10', 6, 20);
  ctx.fillText('⚡ Energy: 10', 6, 30);
}
