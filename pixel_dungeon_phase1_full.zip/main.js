// Phase 1 main loop: world + camera + input
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
let viewW = 320, viewH = 180;         // internal resolution (tiles scaled up)
const TILE = 16;                       // pixels per tile
function resize(){
  // keep 16:9 internal canvas, scale to fit
  const w = window.innerWidth, h = window.innerHeight;
  const scale = Math.max(1, Math.floor(Math.min(w/(viewW), h/(viewH))));
  canvas.width  = viewW;
  canvas.height = viewH;
  canvas.style.width  = (viewW*scale) + 'px';
  canvas.style.height = (viewH*scale) + 'px';
}
addEventListener('resize', resize); resize();

// Dungeon + Player
const dungeon = generateDungeon(60, 40);  // tiles
const player  = new Player(5.5, 5.5);     // tile coords (float)

// Input
const keys = {};
addEventListener('keydown', e=>{ keys[e.key] = true; });
addEventListener('keyup',   e=>{ keys[e.key] = false; });

// Mobile D-pad
const btnUp    = document.querySelector('#dpad .up');
const btnDown  = document.querySelector('#dpad .down');
const btnLeft  = document.querySelector('#dpad .left');
const btnRight = document.querySelector('#dpad .right');
function bindHold(btn, key){
  const down = (e)=>{ e.preventDefault(); keys[key]=true; };
  const up   = (e)=>{ e.preventDefault(); keys[key]=false; };
  btn.addEventListener('touchstart', down, {passive:false});
  btn.addEventListener('touchend',   up,   {passive:false});
  btn.addEventListener('mousedown',  down);
  btn.addEventListener('mouseup',    up);
  btn.addEventListener('mouseleave', up);
}
bindHold(btnUp,'ArrowUp'); bindHold(btnDown,'ArrowDown'); bindHold(btnLeft,'ArrowLeft'); bindHold(btnRight,'ArrowRight');

// Camera follows player; we render a window around them
function draw(){
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0,0,canvas.width,canvas.height);

  // Update player
  player.update(keys, dungeon);

  // Compute camera offset so player stays centered
  const camX = Math.floor(player.x*TILE - viewW/2);
  const camY = Math.floor(player.y*TILE - viewH/2);

  // Draw dungeon tiles near camera
  drawDungeon(ctx, dungeon, camX, camY, TILE);

  // Draw player centered
  player.draw(ctx, viewW/2 - (player.size/2), viewH/2 - (player.size/2));

  // UI
  drawUI(ctx, player);
  requestAnimationFrame(draw);
}
draw();
