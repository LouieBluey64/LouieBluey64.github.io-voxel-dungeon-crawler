// 0 = floor, 1 = wall, 2 = torch, 3 = drip
function generateDungeon(w,h){
  const map = Array.from({length:h},()=>Array(w).fill(0));
  // border walls
  for(let x=0;x<w;x++){ map[0][x]=1; map[h-1][x]=1; }
  for(let y=0;y<h;y++){ map[y][0]=1; map[y][w-1]=1; }
  // random walls
  for(let i=0;i<w*h*0.18;i++){
    const x = 1+Math.floor(Math.random()*(w-2));
    const y = 1+Math.floor(Math.random()*(h-2));
    map[y][x] = 1;
  }
  // carve a simple path so it's not boxed in
  let x=2,y=2;
  for(let i=0;i< w+h; i++){
    map[y][x]=0;
    if(Math.random()<0.5 && x<w-2) x++; else if(y<h-2) y++;
  }
  // scatter torches & drips
  for(let i=0;i<12;i++){
    const tx = 2+Math.floor(Math.random()*(w-4));
    const ty = (Math.random()<0.5)? 1 : h-2;
    map[ty][tx] = 2;
  }
  for(let i=0;i<24;i++){
    const dx = 2+Math.floor(Math.random()*(w-4));
    const dy = 2+Math.floor(Math.random()*(h-4));
    if(map[dy][dx]===0) map[dy][dx] = 3;
  }
  return map;
}

function isWalkable(fx, fy, dungeon){
  const x = Math.floor(fx), y = Math.floor(fy);
  if(y<0||y>=dungeon.length||x<0||x>=dungeon[0].length) return false;
  return dungeon[y][x] !== 1;
}

function drawDungeon(ctx, dungeon, camX, camY, TILE){
  const viewW = ctx.canvas.width, viewH = ctx.canvas.height;
  const startX = Math.max(0, Math.floor(camX / TILE));
  const startY = Math.max(0, Math.floor(camY / TILE));
  const endX   = Math.min(dungeon[0].length, Math.ceil((camX+viewW)/TILE));
  const endY   = Math.min(dungeon.length,    Math.ceil((camY+viewH)/TILE));

  for(let y=startY;y<endY;y++){
    for(let x=startX;x<endX;x++){
      const t = dungeon[y][x];
      const px = x*TILE - camX;
      const py = y*TILE - camY;
      if(t===1){
        ctx.fillStyle = '#17171b';
        ctx.fillRect(px,py,TILE,TILE);
        ctx.fillStyle = '#0d0e12';
        ctx.fillRect(px, py+TILE-3, TILE, 3);
      } else {
        ctx.fillStyle = '#121216';
        ctx.fillRect(px,py,TILE,TILE);
        if(t===3){
          ctx.fillStyle='#151822';
          ctx.fillRect(px+7, py+2, 2, 12); // drip
        }
      }
      if(t===2){
        // torch
        ctx.fillStyle='#3a2a12'; ctx.fillRect(px+6,py+4,4,10);
        ctx.fillStyle= Math.random()>0.5 ? '#ffcf7d':'#ffb84d';
        ctx.fillRect(px+6,py+2,4,3);
        ctx.globalAlpha=0.18; ctx.fillStyle='#ffb84d';
        ctx.fillRect(px-6,py-6,28,28); ctx.globalAlpha=1;
      }
    }
  }
}
