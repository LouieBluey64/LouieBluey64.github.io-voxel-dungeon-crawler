Pixel Dungeon — Phase 1 (Starter)
===================================
What’s inside:
- Basic procedural dungeon (walls, floors, torches, drips)
- Player movement with keyboard (arrow keys) AND mobile D-pad
- Camera that follows the player
- Minimal UI placeholders (hearts/hunger/energy text)

How to run:
1) Upload all files to a new GitHub repo.
2) Enable GitHub Pages (Settings → Pages → Deploy from a branch, main, /root).
3) Open https://YOUR-USERNAME.github.io/YOUR-REPO/

Controls:
- Arrow keys (desktop) or on-screen D-pad (mobile/iPad).

Next steps (Phase 2 idea):
- Add enemies, chests, interaction button, and combat.
